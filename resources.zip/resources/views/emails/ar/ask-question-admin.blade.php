@extends('layouts.email', ['region' => $region ?? 'sa'])
@section('title')
    سؤال خبير - ستارت إيزي.
@endsection
@section('content')
    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" dir="rtl">
        <tr>
            <td style="padding:32px; color:#DBDBDB; text-align: right;" class="content">
                @php
                    $websiteName = ($region ?? 'sa') === 'qa' ? 'موقع قطر' : 'موقع السعودية';
                    $badgeColor = ($region ?? 'sa') === 'qa' ? '#8B1538' : '#006C35';
                @endphp
                <div style="margin-bottom: 16px; text-align: right;">
                    <span style="background-color: {{ $badgeColor }}; color: #ffffff; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                        المصدر: {{ $websiteName }}
                    </span>
                </div>
                <h5 style="font-size:16px; font-weight:600; margin:0 0 24px 0; line-height:24px;">تم إرسال سؤال خبير جديد</h5>
                <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#090D08" style="border-radius:8px;">
                    <tr>
                        <td style="padding: 16px;">
                            <table>
                                <tr>
                                    <th style="text-align: right; color: #8a8a8a">الاسم</th>
                                    <td  style="text-align: right; padding-right: 24px">{{ $data['name'] }}</td>
                                </tr>
                                <tr>
                                    <td style="height: 16px; color: #8a8a8a"></td>
                                    <td style="height: 16px"></td>
                                </tr>
                                <tr>
                                    <th style="text-align: right; color: #8a8a8a">البريد الإلكتروني</th>
                                    <td style="text-align: right; padding-right: 24px">{{ $data['email'] }}</td>
                                </tr>
                                <tr>
                                    <td style="height: 16px"></td>
                                    <td style="height: 16px"></td>
                                </tr>
                                <tr>
                                    <th style="text-align: right; vertical-align: top; color: #8a8a8a">السؤال</th>
                                    <td style="text-align: right; padding-right: 24px; line-height: 24px;">{{ $data['question'] ?? 'لا يوجد' }}</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
@endsection
